//TP         : 06 sugeridos
//EJERCICIO  : 05B
//AUTOR      : Angel Simón - asimon@frgp.utn.edu.ar
//DESCRIPCION: Resuelto con un vector de enteros.
#include <iostream>
using namespace std;

float calcularPotencia(int base, int exponente){
  float resultado=1;
  bool exponenteNegativo = false;
  if (exponente < 0){
    exponenteNegativo = true;
    exponente *= -1;
  }
  for(int i=1; i<=exponente; i++){
    resultado = resultado * base;
  }
  if (exponenteNegativo){
    return 1/resultado;
  }
  return resultado;
}

//Descompone el número numero en cifras (funciona con números menores a 100.000 y mayores a -1)
void cifras(int numero, int *cfr){
    int digitos=5, i;
    for (i=digitos-1; i>=0; i--){
      cfr[i] = numero / calcularPotencia(10, i);
      numero = numero - (cfr[i] * calcularPotencia(10, i));
    }
}

int main(void){
  int numero, v[5];
  cout << "Ingrese un numero para descomponerlo: ";
  cin >> numero;
  cifras(numero, v);
  cout << endl << "EL NUMERO " << numero << " ESTA COMPUESTO POR ";
  for(int i=4; i>=0; i--){
    cout << v[i] << " ";
  }
  return 0;
}
