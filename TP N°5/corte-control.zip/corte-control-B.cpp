/*
Una empresa que vende insumos informáticos posee varias sucursales
en el país. La misma desea conocer información acerca de las ventas
para cada una de sus treinta sucursales. Para cada registro de venta
posee la siguiente información:
- Código de sucursal
- Importe de la venta
- Forma de pago de la venta ('E' – Efectivo ó 'T' - Tarjeta)
La información se encuentra agrupada (no ordenada) por código de
sucursal y el lote de datos se finaliza ingresando un código de sucursal
igual a cero. Se pide informar:
A) El total facturado por cada sucursal.
B) La cantidad de ventas para cada sucursal.
C) El porcentaje de cantidad de ventas por forma de pago (entre todas
las sucursales).
*/
#include <iostream>
using namespace std;

int main(){
  int cSuc, cSucAnt;
  //
  float importe;
  char formaPago;
  //PUNTO A
  float totalFacturado;
  //PUNTO B
  int cantVentas;
  //PUNTO C
  int cantE, cantT;
  cantE=cantT=0;

  cout << "INGRESAR CODIGO DE SUCURSAL: ";
  cin >> cSuc;

  while(cSuc != 0){
    //PUNTO A
    totalFacturado = 0.0;
    //PUNTO B
    cantVentas = 0;

    cSucAnt = cSuc;
      while(cSucAnt == cSuc){
				//PROCESAR PUNTO A
				//PROCESAR PUNTO B
				//PROCESAR PUNTO C
        cout << "INGRESAR CODIGO DE SUCURSAL: ";
        cin >> cSuc;
      }
    //LISTAR PUNTO A
    //LISTAR PUNTO B
  }
  //PROCESAR PUNTO C
  //LISTAR PUNTO C
  return 0;
}
